#!/bin/sh

# Minimalist example playlist script that has the behavior required by
# ezstream.

echo "Great_Artist_-_Great_Song.ogg"
